#define F_CPU 16000000UL

#include <avr/io.h>

#include "spi.h"

int main(void)
{
    SPI::init();

    while (1)
    {

    }
}
